import getHighlightHtml from './highlight_html';
import getHighlightRequestProvider from './highlight_request';

export default {
  getHighlightHtml,
  getHighlightRequestProvider
};
